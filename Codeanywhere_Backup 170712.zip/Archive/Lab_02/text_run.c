#include <stdio.h>

int main(void)
{
  printf("Mahouka Koukou no Rettousei");
  printf("Shigatsu wa Kimi no Uso");
  return 0;
}