#include <stdio.h>

int main(void)
{
  int num_input;
  
  printf("Enter a number: ");
  scanf("%d", &num_input);
  printf("You typed: %d\n", num_input);
  return 0;
}